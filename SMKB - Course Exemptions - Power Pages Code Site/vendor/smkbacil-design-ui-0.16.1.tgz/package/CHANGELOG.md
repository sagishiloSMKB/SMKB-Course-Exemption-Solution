# Changelog

All notable changes to `@smkbacil/design-ui` are documented here.

## Unreleased

> **Breaking — package re-scoped and now private.** This package moved from the public
> `@smkb/design-ui` to the private `@smkbacil/design-ui` (Seminar Hakibutzim business org).
> Update your dependency to `@smkbacil/design-ui` and all imports accordingly, and configure an
> `.npmrc` with a read-only npm token (see README → installation). The old `@smkb/design-ui` is
> deprecated and will no longer receive updates.

### Added

- **`--smkb-z-a11y-overlay`** token (above toast) for accessibility overlays; reading guide uses it instead of a magic z-index.
- **`ariaLabels`** prop on **SmkbAppHeader** (exported type **`AppHeaderAriaLabels`**) for localized landmark strings — defaults preserve previous English labels.
- **`listboxAriaLabel`** on **SmkbSelect** / **SmkbMultiSelect**; **`fallbackAriaLabel`** on **SmkbAvatar**; **`navigationAriaLabel`** on **SmkbSteps**; **`closeAriaLabel`** on **SmkbNotification** — all optional with backward-compatible defaults.
- **`scripts/compare-token-css-vars.mjs`** — build fails if `tokens-nofonts.css` declares any `--smkb-*` variable missing from `tokens.css`.
- **SmkbMultiSelect:** new generic multi-select component with checkboxes, "Select all" master toggle, floating panel (via `useFloatingPosition`), `#trigger` slot for custom triggers, size variants (`sm` / `md` / `lg`), status + message support, disabled/loading states, and full RTL support.
- **SmkbTable — column visibility:** new `columnVisibility` prop adds a `view_column` icon button at the end of the header row that opens a `SmkbMultiSelect` panel to show/hide columns. `defaultHiddenColumns` prop sets which columns are hidden on mount. The last visible column's checkbox is disabled to prevent hiding everything.
- **Design tokens:** Brand palette `--smkb-brand-green` (#4eb764), `--smkb-brand-blue` (#15b7e0), `--smkb-brand-pink` (#cc66a3), `--smkb-brand-yellow` (#f6be53), plus semantic aliases `--smkb-color-brand-*`. Primary (`--smkb-color-primary`) and the green scale are anchored to **brand green**; focus ring uses matching RGBA.

### Changed

- **`tokens-nofonts.css`:** add **`--smkb-z-popover`** (parity with `tokens.css`).
- **`tokens.css`:** **`--smkb-color-brand-*`** semantic aliases aligned with **`tokens-nofonts.css`** (parity check + README consistency).
- **`README.md`:** Modal vs Dialog, Toast vs Notification, `postinstall` behavior, `v-html` trust boundary.
- **`prefers-reduced-motion`:** disable transitions on **SmkbPagination** buttons and **SmkbTable** rows when reduced motion is requested.
- Comments cleaned up on **`SmkbModal`**, **`SmkbTabs`**, **`SmkbSteps`**, **`SmkbNotification`**; **`index.ts`** export section renamed to “Primary component exports”.
- **`CLAUDE.md`:** z-index ladder + token parity note.
- **SmkbAppHeader:** default `variant` changed from `'white'` to `'primary'` (green background).
- **SmkbAppHeader:** mobile drawer (≤768px) uses larger tap targets and safe-area padding on the top bar; opening the drawer pushes `history` state (`__smkbAppHeaderDrawer`) so back gestures close the overlay first (aligned with `SmkbUserMenu`).
- **SmkbDialog:** mobile overlay safe-area padding, larger close control and footer button targets (≤640px); optional modal history trap with sentinel `__smkbDialog` so back closes the dialog before routing.
- **Floating pickers:** `useFloatingPosition` supports `mobileSheet` — at ≤640px list panels render as bottom sheets (`smkb-floating-panel--sheet`). Enabled on **SmkbSelect**, **SmkbAutocomplete**, **SmkbDropdown**, **SmkbMultiSelect**, **SmkbDatePicker**, and **SmkbTimePicker** (not tooltips). Sheet panels use taller option rows / controls where applicable.
- **`SmkbModal`:** forwards **`id`** and **`closeLabel`** to **`SmkbDialog`** (same defaults as dialog).

### Documentation

- **Storybook** (`design-docs`): **SmkbAppHeader** component docs note drawer history/back behavior at ≤768px; MDX **Documentation/Vite and imports**, **Documentation/Brand colors**; **Introduction** and **Component Showcase** link to them; **Design Tokens** story lists brand + semantic sections; **SmkbButton** / **SmkbIconButton** / **SmkbBackButton** stories for neutral-ghost on `surface-subtle` and expanded autodocs.
- **`README.md`** — brand colors table; **`CLAUDE.md`** — Storybook section.

## 0.15.13

### Changed

- **SmkbUserMenu:** fullscreen mobile sheet (≤640px) includes a header close button; on mobile, opening the menu calls `history.pushState` so the device/back gesture closes the overlay before host-app navigation.

## 0.11.8

### Fixed

- **SmkbCheckbox:** `position: relative` on the root label so the visually hidden input is contained; avoids the browser scrolling the page to the top when the checkbox is focused. **`direction: ltr` on the control** so the check and indeterminate dash (logical borders) render correctly in **RTL** locales instead of appearing mirrored or rotated.

### Changed

- **SmkbLayout:** removed the `overflow: clip` / `@supports` experiment; shell uses `overflow: hidden` only.

## 0.11.7

### Changed

- **`createSmkb` / public API:** single registry (`smkbPluginComponents`) + parity test. **Build:** stricter `verify-dist-exports` (tokens, `useSmkbToast`). **CI:** `dev` + `main`; no `build:tokens` step. **ESLint:** `no-explicit-any` error, `lint` uses `--max-warnings 0`. **Docs** align on `@smkbacil/design-ui` for tokens; Storybook stories match component props; preview uses typed `Decorator`.

### Fixed

- **SmkbField / stories:** `SmkbInput` and `SmkbSelect` stories use `SmkbField` for labels; pagination uses `v-model:currentPage` and real `argTypes`.

## 0.6.1

### Fixed

- **Vite consumers:** Document `optimizeDeps.exclude: ['@smkbacil/design-ui']` and clearing `node_modules/.vite` when named imports fail after prebundling. Added `"default"` to `package.json` `exports["."]` for broader tool compatibility.
- **SmkbIconButton:** Slot-only icons (e.g. `SmkbBackButton` inline SVG) now get the same SVG sizing as bundled `icon` glyphs via `.smkb-icon-button__content svg` styles.
- **Neutral ghost** (`SmkbIconButton`, `SmkbButton`): hover/active use gray steps (`--smkb-gray-100` / `--smkb-gray-200` in light; `--smkb-gray-700` / `--smkb-gray-600` in dark) instead of `--smkb-color-surface-subtle`, so the fill stays visible on layouts that use `surface-subtle` as the background.

### Added

- Storybook story **Default slot only (no icon prop)** on `SmkbIconButton`.
- Tests: public API export smoke (`public-api.exports.test.ts`), slot-only `SmkbIconButton` render test, and `scripts/verify-dist-exports.mjs` (`pnpm run verify:exports` after build).
